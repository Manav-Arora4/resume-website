import { useState, useEffect, useRef, useMemo } from 'react'

// ─── Hooks ────────────────────────────────────────────────────────────────

function useInView(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null)
  const [inView, setInView] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true)
          obs.disconnect()
        }
      },
      { threshold }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [threshold])
  return { ref, inView }
}

function useCountUp(target: number, duration = 1800, active = false) {
  const [count, setCount] = useState(0)
  useEffect(() => {
    if (!active) return
    let start: number | null = null
    const step = (ts: number) => {
      if (!start) start = ts
      const progress = Math.min((ts - start) / duration, 1)
      setCount(Math.floor(progress * target))
      if (progress < 1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  }, [target, duration, active])
  return count
}

// ─── Data ─────────────────────────────────────────────────────────────────

const skillCategories = [
  {
    name: 'Programming',
    icon: '⌨️',
    color: '#3B82F6',
    skills: [
      { name: 'Python', level: 92 },
      { name: 'C++', level: 75 },
      { name: 'JavaScript / TS', level: 78 },
      { name: 'SQL', level: 82 },
    ],
  },
  {
    name: 'Machine Learning',
    icon: '🧠',
    color: '#14B8A6',
    skills: [
      { name: 'Scikit-learn', level: 90 },
      { name: 'XGBoost / LightGBM', level: 85 },
      { name: 'Feature Engineering', level: 87 },
      { name: 'Model Evaluation', level: 88 },
    ],
  },
  {
    name: 'Deep Learning',
    icon: '🔮',
    color: '#8B5CF6',
    skills: [
      { name: 'PyTorch', level: 86 },
      { name: 'TensorFlow / Keras', level: 80 },
      { name: 'Neural Architecture', level: 76 },
      { name: 'Transfer Learning', level: 83 },
    ],
  },
  {
    name: 'Computer Vision',
    icon: '👁️',
    color: '#10B981',
    skills: [
      { name: 'OpenCV', level: 85 },
      { name: 'YOLO v8 / v11', level: 82 },
      { name: 'Image Segmentation', level: 76 },
      { name: 'Object Detection', level: 84 },
    ],
  },
  {
    name: 'Generative AI',
    icon: '✨',
    color: '#F59E0B',
    skills: [
      { name: 'LLM Integration', level: 80 },
      { name: 'LangChain / LlamaIndex', level: 74 },
      { name: 'Prompt Engineering', level: 86 },
      { name: 'RAG Systems', level: 73 },
    ],
  },
  {
    name: 'Cloud & DevOps',
    icon: '☁️',
    color: '#0EA5E9',
    skills: [
      { name: 'AWS (S3, EC2, SageMaker)', level: 70 },
      { name: 'Docker / Containers', level: 76 },
      { name: 'FastAPI / Flask', level: 82 },
      { name: 'Git / GitHub Actions', level: 88 },
    ],
  },
]

const achievements = [
  { icon: '🏆', title: 'AI Pioneer', desc: '15+ production ML systems', color: '#F59E0B' },
  { icon: '🔬', title: 'Researcher', desc: '8+ papers implemented', color: '#3B82F6' },
  { icon: '🎯', title: 'Precision', desc: '95%+ model accuracy', color: '#10B981' },
  { icon: '⚡', title: 'Optimizer', desc: '10× inference speedup', color: '#8B5CF6' },
  { icon: '🌐', title: 'Full Stack AI', desc: 'End-to-end deployment', color: '#14B8A6' },
  { icon: '🤝', title: 'Open Source', desc: '100+ contributions', color: '#EC4899' },
]

const projects = [
  {
    title: 'Financial Statement Analyzer',
    desc: 'Automated extraction and analysis of financial documents using NLP and transformer models to surface investment signals and key financial metrics.',
    tech: ['Python', 'Transformers', 'NLP', 'FastAPI', 'PostgreSQL'],
    metrics: ['92% accuracy', '10,000+ docs', '3× faster analysis'],
    accent: '#3B82F6',
    emoji: '📊',
  },
  {
    title: 'YOLOv11 Cone Detection',
    desc: 'Real-time traffic cone detection for autonomous vehicle navigation using custom-trained YOLOv11 with enhanced small-object detection.',
    tech: ['Python', 'YOLOv11', 'OpenCV', 'CUDA', 'TensorRT'],
    metrics: ['96.3% mAP@50', '45 FPS real-time', '2k custom images'],
    accent: '#14B8A6',
    emoji: '🎯',
  },
  {
    title: 'Phishing Email Detection',
    desc: 'ML-powered email security combining NLP text analysis with header pattern recognition to catch sophisticated phishing attempts.',
    tech: ['Python', 'Scikit-learn', 'BERT', 'Pandas', 'Flask'],
    metrics: ['98.2% detection', '0.3% false positive', 'Real-time scoring'],
    accent: '#8B5CF6',
    emoji: '🛡️',
  },
  {
    title: 'FPS Prediction Model',
    desc: 'Predictive model for game performance optimization — estimates frame rate from hardware configuration and graphics settings.',
    tech: ['Python', 'XGBoost', 'Feature Engineering', 'Streamlit'],
    metrics: ['MAE: 2.3 FPS', 'R² = 0.94', '15k+ data points'],
    accent: '#F59E0B',
    emoji: '🎮',
  },
  {
    title: 'House Price Prediction',
    desc: 'Gradient boosting ensemble with ridge regression and neural networks; extensive feature engineering for maximum predictive power.',
    tech: ['Python', 'LightGBM', 'Ridge', 'Neural Net', 'Pandas'],
    metrics: ['RMSE: $12,400', 'Top 8% Kaggle', 'Stacked ensemble'],
    accent: '#0EA5E9',
    emoji: '🏠',
  },
  {
    title: 'Anime Recommendation System',
    desc: 'Collaborative + content-based filtering with embeddings and cosine similarity across 10,000+ anime titles with sub-50ms response time.',
    tech: ['Python', 'CF Filtering', 'Embeddings', 'FastAPI', 'Redis'],
    metrics: ['94% satisfaction', '10k+ titles', '<50ms response'],
    accent: '#EC4899',
    emoji: '🎌',
  },
]

const currentlyLearning = [
  { topic: 'Reinforcement Learning', progress: 45, icon: '🎮', color: '#8B5CF6' },
  { topic: 'Diffusion Models', progress: 60, icon: '🎨', color: '#EC4899' },
  { topic: 'Large Language Models', progress: 72, icon: '🤖', color: '#14B8A6' },
  { topic: 'MLOps & Model Serving', progress: 55, icon: '🚀', color: '#3B82F6' },
]

const timelineItems = [
  {
    year: '2024',
    title: 'AI Research Intern',
    org: 'Tech Startup',
    desc: 'Developed computer vision pipelines for autonomous systems. Built and deployed YOLOv11-based detection models achieving 96% mAP in production.',
    type: 'work',
    tags: ['Computer Vision', 'PyTorch', 'YOLOv11', 'TensorRT'],
  },
  {
    year: '2023',
    title: 'ML Projects & Kaggle',
    org: 'Independent Research',
    desc: 'Built 10+ end-to-end ML systems across NLP, CV, and tabular domains. Reached top 8% on a major Kaggle regression competition.',
    type: 'project',
    tags: ['NLP', 'Kaggle', 'Scikit-learn', 'Deep Learning'],
  },
  {
    year: '2022',
    title: 'B.Tech — Computer Science',
    org: 'XYZ University',
    desc: 'Focused on AI/ML: Machine Learning, Deep Learning, Computer Vision, Algorithms, and Statistics. Active in ML Research Club.',
    type: 'education',
    tags: ['Algorithms', 'ML', 'CV', 'Statistics'],
  },
  {
    year: '2021',
    title: 'First Neural Network',
    org: 'Personal Project',
    desc: 'Built a neural network from scratch in NumPy. Launched Kaggle journey, started open-source contributions.',
    type: 'milestone',
    tags: ['Python', 'NumPy', 'Neural Nets'],
  },
]

const certifications = [
  { title: 'Deep Learning Specialization', issuer: 'DeepLearning.AI / Coursera', date: '2023', color: '#3B82F6' },
  { title: 'Machine Learning Specialization', issuer: 'Stanford / Coursera', date: '2023', color: '#14B8A6' },
  { title: 'AWS Solutions Architect', issuer: 'Amazon Web Services', date: '2024', color: '#F59E0B' },
  { title: 'TensorFlow Developer', issuer: 'Google / Coursera', date: '2023', color: '#10B981' },
  { title: 'Computer Vision Nanodegree', issuer: 'Udacity', date: '2023', color: '#8B5CF6' },
  { title: 'Applied Data Science', issuer: 'IBM / Coursera', date: '2022', color: '#EC4899' },
]

const statsData = [
  { label: 'Projects Completed', value: 15, suffix: '+' },
  { label: 'Internships', value: 2, suffix: '' },
  { label: 'Technologies', value: 30, suffix: '+' },
  { label: 'GitHub Repos', value: 42, suffix: '' },
]

// Pre-computed contribution grid to avoid random re-renders
function buildContribGrid() {
  const seed = [
    0, 0, 1, 0, 0, 2, 0, 1, 0, 0, 3, 0, 1, 0, 0, 0, 2, 1, 0, 3, 1, 0, 0, 2, 0,
    1, 0, 0, 4, 0, 1, 1, 0, 3, 0, 0, 0, 2, 1, 0, 4, 1, 0, 0, 2, 0, 1, 0, 0, 3,
    0, 4,
  ]
  const row = [
    1, 0, 3, 0, 2, 0, 0, 1, 4, 0, 3, 0, 0, 2, 1, 0, 4, 1, 0, 0, 3, 0, 2, 1, 0,
    4, 0, 0, 2, 1, 0, 3, 0, 0, 4, 1, 0, 2, 0, 3, 1, 0, 0, 4, 2, 0, 1, 0, 3, 0,
    0, 2,
  ]
  const grid: number[] = []
  for (let r = 0; r < 7; r++) {
    for (let c = 0; c < 52; c++) {
      grid.push((seed[c] + row[c % 7] + r) % 5)
    }
  }
  return grid
}

const contribGrid = buildContribGrid()

// ─── UI Primitives ────────────────────────────────────────────────────────

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-center gap-2 mb-4">
      <div className="h-px w-8" style={{ background: 'linear-gradient(90deg, transparent, #14B8A6)' }} />
      <span
        className="text-xs font-semibold tracking-widest uppercase"
        style={{ color: '#14B8A6' }}
      >
        {children}
      </span>
      <div className="h-px w-8" style={{ background: 'linear-gradient(90deg, #14B8A6, transparent)' }} />
    </div>
  )
}

function SectionTitle({
  children,
  className = '',
}: {
  children: React.ReactNode
  className?: string
}) {
  return (
    <h2 className={`text-3xl md:text-4xl font-bold text-white ${className}`}>
      {children}
    </h2>
  )
}

// ─── AI Illustration ──────────────────────────────────────────────────────

function AIIllustration() {
  return (
    <div className="relative w-full flex items-center justify-center" style={{ minHeight: 380 }}>
      <div
        className="absolute inset-0"
        style={{
          background: 'radial-gradient(ellipse at center, rgba(20,184,166,0.12) 0%, transparent 65%)',
          filter: 'blur(20px)',
        }}
      />
      <svg
        viewBox="0 0 400 400"
        className="w-full max-w-sm md:max-w-md animate-float"
        fill="none"
      >
        <defs>
          <linearGradient id="lg1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#14B8A6" />
            <stop offset="100%" stopColor="#3B82F6" />
          </linearGradient>
          <linearGradient id="lg2" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#3B82F6" />
            <stop offset="100%" stopColor="#8B5CF6" />
          </linearGradient>
          <linearGradient id="lg3" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#10B981" />
            <stop offset="100%" stopColor="#14B8A6" />
          </linearGradient>
          <linearGradient id="lgCore" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#14B8A6" />
            <stop offset="50%" stopColor="#3B82F6" />
            <stop offset="100%" stopColor="#8B5CF6" />
          </linearGradient>
          <radialGradient id="rgBg" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#14B8A6" stopOpacity="0.1" />
            <stop offset="100%" stopColor="#0B1120" stopOpacity="0" />
          </radialGradient>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="2.5" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        <circle cx="200" cy="200" r="185" fill="url(#rgBg)" />

        {/* Outer orbit */}
        <ellipse
          cx="200"
          cy="200"
          rx="162"
          ry="62"
          stroke="url(#lg1)"
          strokeWidth="1"
          strokeOpacity="0.35"
          strokeDasharray="10 5"
          className="animate-spin-slow"
        />
        {/* Middle orbit */}
        <ellipse
          cx="200"
          cy="200"
          rx="122"
          ry="48"
          stroke="url(#lg2)"
          strokeWidth="1"
          strokeOpacity="0.45"
          strokeDasharray="7 4"
          className="animate-spin-slow-reverse"
        />
        {/* Inner orbit */}
        <ellipse
          cx="200"
          cy="200"
          rx="86"
          ry="34"
          stroke="url(#lg3)"
          strokeWidth="1.5"
          strokeOpacity="0.6"
          className="animate-spin-slow"
        />

        {/* Connection spokes */}
        {[
          [200, 200, 72, 92, '#14B8A6'],
          [200, 200, 336, 108, '#3B82F6'],
          [200, 200, 348, 284, '#8B5CF6'],
          [200, 200, 62, 296, '#10B981'],
          [200, 200, 200, 44, '#F59E0B'],
          [200, 200, 338, 200, '#0EA5E9'],
        ].map(([x1, y1, x2, y2, color], i) => (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke={color as string}
            strokeWidth="0.6"
            strokeOpacity="0.28"
          />
        ))}

        {/* Satellite nodes */}
        <g filter="url(#glow)">
          {[
            { cx: 72, cy: 92, r: 8, color: '#14B8A6', label: 'ML' },
            { cx: 336, cy: 108, r: 10, color: '#3B82F6', label: 'CV' },
            { cx: 348, cy: 284, r: 7, color: '#8B5CF6', label: 'GenAI' },
            { cx: 62, cy: 296, r: 9, color: '#10B981', label: 'NLP' },
            { cx: 200, cy: 44, r: 6, color: '#F59E0B', label: 'RL' },
            { cx: 338, cy: 200, r: 7.5, color: '#0EA5E9', label: 'MLOps' },
          ].map((n, i) => (
            <g key={i}>
              <circle cx={n.cx} cy={n.cy} r={n.r + 7} fill="none" stroke={n.color} strokeWidth="0.8" strokeOpacity="0.25" />
              <circle cx={n.cx} cy={n.cy} r={n.r} fill={n.color} fillOpacity="0.85" />
            </g>
          ))}

          {/* Micro dots */}
          {[
            [148, 78, '#14B8A6'],
            [278, 155, '#3B82F6'],
            [244, 334, '#8B5CF6'],
            [116, 238, '#10B981'],
            [304, 222, '#14B8A6'],
          ].map(([cx, cy, color], i) => (
            <circle key={i} cx={cx as number} cy={cy as number} r="2.5" fill={color as string} fillOpacity="0.45" />
          ))}
        </g>

        {/* Core hexagon shell */}
        <polygon
          points="200,144 232,162 232,198 200,216 168,198 168,162"
          fill="rgba(20,184,166,0.07)"
          stroke="url(#lgCore)"
          strokeWidth="1.5"
        />
        <polygon
          points="200,157 222,168 222,192 200,203 178,192 178,168"
          fill="rgba(59,130,246,0.1)"
          stroke="url(#lg1)"
          strokeWidth="1"
          strokeOpacity="0.55"
        />

        {/* Core orb */}
        <circle cx="200" cy="180" r="20" fill="url(#lgCore)" fillOpacity="0.9" />
        <circle cx="200" cy="180" r="11" fill="white" fillOpacity="0.18" />
        <circle cx="196" cy="176" r="4" fill="white" fillOpacity="0.45" />

        {/* Label chips */}
        {[
          { x: 45, y: 78, w: 50, color: '#14B8A6', text: 'ML Model' },
          { x: 295, y: 94, w: 62, color: '#3B82F6', text: 'Comp. Vision' },
          { x: 316, y: 270, w: 52, color: '#8B5CF6', text: 'Gen AI' },
          { x: 30, y: 282, w: 52, color: '#10B981', text: 'NLP / LLMs' },
          { x: 170, y: 30, w: 60, color: '#F59E0B', text: 'Reinf. Learn.' },
        ].map((chip, i) => (
          <g key={i}>
            <rect
              x={chip.x}
              y={chip.y}
              width={chip.w}
              height={17}
              rx="8.5"
              fill={`${chip.color}18`}
              stroke={chip.color}
              strokeWidth="0.6"
              strokeOpacity="0.5"
            />
            <text
              x={chip.x + chip.w / 2}
              y={chip.y + 11}
              textAnchor="middle"
              fill={chip.color}
              fontSize="6.5"
              fontFamily="Inter"
              fontWeight="600"
            >
              {chip.text}
            </text>
          </g>
        ))}
      </svg>
    </div>
  )
}

// ─── Navbar ───────────────────────────────────────────────────────────────

function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const navLinks = ['Home', 'About', 'Projects', 'Experience', 'Skills', 'Contact']

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: scrolled ? 'rgba(11,17,32,0.88)' : 'transparent',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        WebkitBackdropFilter: scrolled ? 'blur(20px)' : 'none',
        borderBottom: scrolled ? '1px solid rgba(255,255,255,0.06)' : 'none',
      }}
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <a href="#home" className="flex items-center gap-2.5">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs text-white"
            style={{ background: 'linear-gradient(135deg, #14B8A6, #3B82F6)' }}
          >
            MA
          </div>
          <span className="font-semibold text-white text-sm hidden sm:block">Manav Arora</span>
        </a>

        <div className="hidden md:flex items-center gap-0.5">
          {navLinks.map((link) => (
            <a
              key={link}
              href={`#${link.toLowerCase()}`}
              className="px-3.5 py-1.5 text-sm text-gray-400 hover:text-white rounded-lg transition-all duration-200 hover:bg-white/5"
            >
              {link}
            </a>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-3">
          <a
            href="#"
            className="px-4 py-2 text-sm font-semibold rounded-xl border transition-all duration-200 hover:scale-105"
            style={{ borderColor: 'rgba(20,184,166,0.45)', color: '#14B8A6' }}
          >
            Resume ↗
          </a>
        </div>

        <button
          className="md:hidden p-2 text-gray-400 hover:text-white"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          <div
            className="w-5 h-0.5 bg-current mb-1.5 transition-all duration-200"
            style={{ transform: mobileOpen ? 'rotate(45deg) translate(0, 6px)' : 'none' }}
          />
          <div
            className="w-5 h-0.5 bg-current mb-1.5 transition-all duration-200"
            style={{ opacity: mobileOpen ? 0 : 1 }}
          />
          <div
            className="w-5 h-0.5 bg-current transition-all duration-200"
            style={{ transform: mobileOpen ? 'rotate(-45deg) translate(0, -6px)' : 'none' }}
          />
        </button>
      </div>

      {mobileOpen && (
        <div className="md:hidden glass-card mx-4 mb-4 rounded-2xl p-4 border" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
          {navLinks.map((link) => (
            <a
              key={link}
              href={`#${link.toLowerCase()}`}
              className="block px-3 py-2.5 text-sm text-gray-300 hover:text-white rounded-xl hover:bg-white/5 transition-all"
              onClick={() => setMobileOpen(false)}
            >
              {link}
            </a>
          ))}
          <div className="mt-3 pt-3 border-t" style={{ borderColor: 'rgba(255,255,255,0.08)' }}>
            <a
              href="#"
              className="block px-3 py-2.5 text-sm font-semibold rounded-xl text-center text-white"
              style={{ background: 'linear-gradient(135deg, #14B8A6, #3B82F6)' }}
            >
              Download Resume
            </a>
          </div>
        </div>
      )}
    </nav>
  )
}

// ─── Hero ─────────────────────────────────────────────────────────────────

function Hero() {
  const { ref, inView } = useInView(0.1)

  return (
    <section id="home" className="relative min-h-screen flex items-center pt-16 overflow-hidden grid-bg">
      <div
        className="blob w-96 h-96 opacity-25 top-24 -left-24"
        style={{ background: '#14B8A6' }}
      />
      <div
        className="blob w-72 h-72 opacity-15 top-48 -right-12"
        style={{ background: '#3B82F6' }}
      />
      <div
        className="blob w-56 h-56 opacity-10 bottom-24 left-1/3"
        style={{ background: '#8B5CF6' }}
      />

      <div className="max-w-7xl mx-auto px-6 py-24 w-full" ref={ref}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div
            className="transition-all duration-700"
            style={{ opacity: inView ? 1 : 0, transform: inView ? 'translateY(0)' : 'translateY(24px)' }}
          >
            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold mb-8"
              style={{
                background: 'rgba(20,184,166,0.1)',
                border: '1px solid rgba(20,184,166,0.28)',
                color: '#14B8A6',
              }}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-current" style={{ animation: 'pulse-beacon 2s ease-in-out infinite' }} />
              Open to opportunities — Full-time & Internships
            </div>

            <h1 className="text-5xl md:text-6xl lg:text-[72px] font-extrabold text-white leading-none tracking-tighter mb-4">
              Manav
              <br />
              <span className="gradient-text">Arora</span>
            </h1>

            <div className="text-base md:text-lg font-semibold mb-5" style={{ color: '#14B8A6', letterSpacing: '0.02em' }}>
              AI & Machine Learning Engineer
            </div>

            <p className="text-gray-400 text-base md:text-lg leading-relaxed mb-10 max-w-lg">
              Building intelligent systems using Machine Learning, Computer Vision,
              NLP, and Generative AI to solve real-world problems.
            </p>

            <div className="flex flex-wrap gap-3">
              <a
                href="#projects"
                className="px-6 py-3 rounded-xl font-semibold text-sm text-white transition-all duration-200 hover:scale-105 hover:brightness-110"
                style={{
                  background: 'linear-gradient(135deg, #14B8A6, #3B82F6)',
                  boxShadow: '0 0 24px rgba(20,184,166,0.28)',
                }}
              >
                View Projects →
              </a>
              <a
                href="#"
                className="px-6 py-3 rounded-xl font-semibold text-sm text-white border transition-all duration-200 hover:scale-105 hover:bg-white/5"
                style={{ borderColor: 'rgba(255,255,255,0.14)' }}
              >
                Download Resume
              </a>
              <a
                href="#"
                className="px-4 py-3 rounded-xl border transition-all duration-200 hover:scale-105 hover:bg-white/5 flex items-center"
                style={{ borderColor: 'rgba(255,255,255,0.1)', color: '#9CA3AF' }}
                aria-label="GitHub"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0 0 24 12c0-6.63-5.37-12-12-12z" />
                </svg>
              </a>
              <a
                href="#"
                className="px-4 py-3 rounded-xl border transition-all duration-200 hover:scale-105 hover:bg-white/5 flex items-center"
                style={{ borderColor: 'rgba(255,255,255,0.1)', color: '#9CA3AF' }}
                aria-label="LinkedIn"
              >
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                </svg>
              </a>
            </div>
          </div>

          <div
            className="transition-all duration-700"
            style={{
              opacity: inView ? 1 : 0,
              transform: inView ? 'translateX(0)' : 'translateX(24px)',
              transitionDelay: '180ms',
            }}
          >
            <AIIllustration />
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Stats ────────────────────────────────────────────────────────────────

function StatCard({
  label,
  value,
  suffix,
  active,
}: {
  label: string
  value: number
  suffix: string
  active: boolean
}) {
  const count = useCountUp(value, 1800, active)
  return (
    <div className="glass-card rounded-2xl p-6 text-center">
      <div className="text-3xl font-extrabold gradient-text tabular-nums">
        {count}
        {suffix}
      </div>
      <div className="text-xs text-gray-500 mt-1.5 font-medium tracking-wide uppercase">{label}</div>
    </div>
  )
}

function Stats() {
  const { ref, inView } = useInView(0.3)
  return (
    <section className="py-16 border-y" style={{ borderColor: 'rgba(255,255,255,0.05)' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4" ref={ref}>
          {statsData.map((s) => (
            <StatCard key={s.label} {...s} active={inView} />
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── About ────────────────────────────────────────────────────────────────

function About() {
  return (
    <section id="about" className="py-24 border-b" style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          <div>
            <SectionLabel>About Me</SectionLabel>
            <SectionTitle className="mb-6">
              Passionate about{' '}
              <span className="gradient-text">AI Research</span>
            </SectionTitle>
            <p className="text-gray-400 leading-relaxed mb-5">
              I'm an AI & ML Engineer passionate about building systems that solve real problems.
              My journey started with curiosity about how machines could learn, and has evolved
              into working on production-grade computer vision, NLP, and generative AI systems.
            </p>
            <p className="text-gray-400 leading-relaxed mb-8">
              I love the intersection of research and engineering — taking ideas from papers and
              turning them into working code that actually ships. Currently diving deep into large
              language models, diffusion models, and reinforcement learning.
            </p>
            <a
              href="#contact"
              className="inline-flex px-5 py-2.5 rounded-xl text-sm font-semibold text-white transition-all hover:scale-105"
              style={{ background: 'linear-gradient(135deg, #14B8A6, #3B82F6)' }}
            >
              Get in touch →
            </a>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {[
              { icon: '📍', label: 'Location', value: 'India — Open to Remote & Relocation' },
              { icon: '💼', label: 'Status', value: 'Open to full-time & internships' },
              { icon: '🎯', label: 'Focus Areas', value: 'Computer Vision · GenAI · MLOps' },
              { icon: '⏱️', label: 'Experience', value: '3+ years building ML systems' },
              { icon: '🎓', label: 'Education', value: 'B.Tech CS — XYZ University (2026)' },
            ].map((fact) => (
              <div
                key={fact.label}
                className="glass-card rounded-xl p-4 flex items-center gap-4 gradient-border"
              >
                <div className="text-2xl">{fact.icon}</div>
                <div>
                  <div className="text-xs text-gray-500 uppercase tracking-wider mb-0.5">{fact.label}</div>
                  <div className="text-sm font-medium text-white">{fact.value}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Skills ───────────────────────────────────────────────────────────────

function SkillBar({
  name,
  level,
  color,
  delay,
  animate,
}: {
  name: string
  level: number
  color: string
  delay: number
  animate: boolean
}) {
  return (
    <div className="mb-4 last:mb-0">
      <div className="flex justify-between items-center mb-1.5">
        <span className="text-xs text-gray-300 font-medium">{name}</span>
        <span
          className="text-xs font-semibold"
          style={{ fontFamily: "'JetBrains Mono', monospace", color }}
        >
          {animate ? level : 0}%
        </span>
      </div>
      <div className="h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
        <div
          className="h-full rounded-full"
          style={{
            width: animate ? `${level}%` : '0%',
            background: `linear-gradient(90deg, ${color}, ${color}bb)`,
            transition: `width ${1100 + delay}ms cubic-bezier(0.25,0.46,0.45,0.94) ${delay}ms`,
            boxShadow: animate ? `0 0 6px ${color}55` : 'none',
          }}
        />
      </div>
    </div>
  )
}

function Skills() {
  const { ref, inView } = useInView(0.08)
  const [unlocked, setUnlocked] = useState<number[]>([])

  useEffect(() => {
    if (!inView) return
    achievements.forEach((_, i) => {
      setTimeout(
        () => setUnlocked((prev) => [...prev, i]),
        600 + i * 280
      )
    })
  }, [inView])

  return (
    <section id="skills" className="py-24 border-b" style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <SectionLabel>Technical Skills</SectionLabel>
          <SectionTitle>
            Skill <span className="gradient-text">Arsenal</span>
          </SectionTitle>
          <p className="text-gray-500 mt-4 max-w-lg mx-auto text-sm">
            Proficiency across the full AI/ML stack — raw data to deployed production models.
          </p>
        </div>

        {/* Achievements */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 mb-16">
          {achievements.map((ach, i) => {
            const isUnlocked = unlocked.includes(i)
            return (
              <div
                key={i}
                className="glass-card rounded-xl p-3 text-center"
                style={{
                  opacity: isUnlocked ? 1 : 0.25,
                  transform: isUnlocked ? 'scale(1)' : 'scale(0.9)',
                  transition: 'opacity 0.2s, transform 0.2s',
                  animation: isUnlocked ? 'achievementPop 0.55s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards' : 'none',
                  border: isUnlocked ? `1px solid ${ach.color}28` : '1px solid rgba(255,255,255,0.07)',
                }}
              >
                <div className="text-2xl mb-1">{ach.icon}</div>
                <div className="text-xs font-bold text-white leading-tight">{ach.title}</div>
                <div className="text-xs text-gray-600 mt-0.5 leading-tight">{ach.desc}</div>
                <div
                  className="text-xs mt-1.5 font-semibold"
                  style={{ color: isUnlocked ? ach.color : 'transparent', transition: 'color 0.3s' }}
                >
                  ✓ Unlocked
                </div>
              </div>
            )
          })}
        </div>

        {/* Skill bars grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5" ref={ref}>
          {skillCategories.map((cat) => (
            <div key={cat.name} className="glass-card rounded-2xl p-6 gradient-border">
              <div className="flex items-center gap-2.5 mb-5">
                <span className="text-lg">{cat.icon}</span>
                <span className="font-semibold text-white text-sm">{cat.name}</span>
                <div
                  className="ml-auto h-px flex-1 rounded-full opacity-25"
                  style={{ background: cat.color }}
                />
              </div>
              {cat.skills.map((skill, si) => (
                <SkillBar
                  key={skill.name}
                  name={skill.name}
                  level={skill.level}
                  color={cat.color}
                  delay={si * 120}
                  animate={inView}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Projects ─────────────────────────────────────────────────────────────

function ProjectCard({
  project,
  index,
}: {
  project: (typeof projects)[number]
  index: number
}) {
  const [hovered, setHovered] = useState(false)

  return (
    <div
      className="glass-card rounded-2xl overflow-hidden gradient-border flex flex-col"
      style={{
        transform: hovered ? 'translateY(-5px)' : 'translateY(0)',
        transition: 'transform 0.3s ease, box-shadow 0.3s ease',
        boxShadow: hovered ? `0 24px 48px ${project.accent}18` : 'none',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div
        className="h-44 flex items-center justify-center relative overflow-hidden flex-shrink-0"
        style={{ background: `${project.accent}10` }}
      >
        <div
          className="absolute inset-0 transition-transform duration-500"
          style={{
            background: `radial-gradient(ellipse at center, ${project.accent}20, transparent 70%)`,
            transform: hovered ? 'scale(1.08)' : 'scale(1)',
          }}
        />
        <div className="relative z-10 text-center">
          <div className="text-5xl mb-1.5">{project.emoji}</div>
          <div className="text-xs text-gray-600">Project Preview</div>
        </div>
      </div>

      <div className="p-5 flex flex-col flex-1">
        <h3 className="font-bold text-white text-base mb-2">{project.title}</h3>
        <p className="text-gray-500 text-xs leading-relaxed mb-3 flex-1">{project.desc}</p>

        <div className="flex flex-wrap gap-1.5 mb-3">
          {project.metrics.map((m) => (
            <span
              key={m}
              className="text-xs px-2 py-0.5 rounded-full font-medium"
              style={{ background: `${project.accent}14`, color: project.accent }}
            >
              {m}
            </span>
          ))}
        </div>

        <div className="flex flex-wrap gap-1 mb-4">
          {project.tech.map((t) => (
            <span
              key={t}
              className="text-xs px-2 py-0.5 rounded-md"
              style={{
                background: 'rgba(255,255,255,0.05)',
                color: '#6B7280',
                fontFamily: "'JetBrains Mono', monospace",
              }}
            >
              {t}
            </span>
          ))}
        </div>

        <div className="flex gap-2">
          <a
            href="#"
            className="flex-1 py-2 text-xs font-semibold rounded-lg text-center text-white transition-all hover:brightness-110"
            style={{ background: project.accent }}
          >
            GitHub →
          </a>
          <a
            href="#"
            className="flex-1 py-2 text-xs font-semibold rounded-lg text-center border transition-all hover:bg-white/5"
            style={{ borderColor: 'rgba(255,255,255,0.1)', color: '#9CA3AF' }}
          >
            Live Demo
          </a>
        </div>
      </div>
    </div>
  )
}

function Projects() {
  const featured = projects[0]

  return (
    <section id="projects" className="py-24 border-b" style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <SectionLabel>Portfolio</SectionLabel>
          <SectionTitle>
            Featured <span className="gradient-text">Projects</span>
          </SectionTitle>
          <p className="text-gray-500 mt-4 max-w-xl mx-auto text-sm">
            Production-grade AI systems with measurable real-world impact.
          </p>
        </div>

        {/* Featured full-width case study */}
        <div
          className="glass-card rounded-3xl overflow-hidden mb-8 gradient-border"
          style={{ boxShadow: '0 0 60px rgba(20,184,166,0.07)' }}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-10 flex flex-col justify-center">
              <div
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold mb-6 w-fit"
                style={{
                  background: 'rgba(20,184,166,0.1)',
                  border: '1px solid rgba(20,184,166,0.2)',
                  color: '#14B8A6',
                }}
              >
                ⭐ Case Study — Featured Project
              </div>
              <h3 className="text-2xl lg:text-3xl font-bold text-white mb-4">
                {featured.title}
              </h3>
              <p className="text-gray-400 leading-relaxed mb-6 text-sm">
                {featured.desc} The pipeline integrates with SEC EDGAR, processes 10-K and 10-Q
                filings, and surfaces actionable signals for equity analysts — reducing manual
                review time from hours to minutes.
              </p>

              <div className="grid grid-cols-3 gap-3 mb-6">
                {featured.metrics.map((m) => (
                  <div
                    key={m}
                    className="text-center p-3 rounded-xl"
                    style={{ background: 'rgba(20,184,166,0.06)', border: '1px solid rgba(20,184,166,0.1)' }}
                  >
                    <div className="text-sm font-bold" style={{ color: '#14B8A6' }}>
                      {m.split(' ')[0]}
                    </div>
                    <div className="text-xs text-gray-600 mt-0.5">
                      {m.split(' ').slice(1).join(' ')}
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex flex-wrap gap-1.5 mb-6">
                {featured.tech.map((t) => (
                  <span
                    key={t}
                    className="text-xs px-2.5 py-1 rounded-md font-mono"
                    style={{
                      background: 'rgba(20,184,166,0.08)',
                      color: '#14B8A6',
                      border: '1px solid rgba(20,184,166,0.14)',
                      fontFamily: "'JetBrains Mono', monospace",
                    }}
                  >
                    {t}
                  </span>
                ))}
              </div>

              <div className="flex gap-3">
                <a
                  href="#"
                  className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white transition-all hover:scale-105"
                  style={{ background: 'linear-gradient(135deg, #14B8A6, #3B82F6)' }}
                >
                  View on GitHub →
                </a>
                <a
                  href="#"
                  className="px-5 py-2.5 rounded-xl text-sm font-semibold border transition-all hover:bg-white/5"
                  style={{ borderColor: 'rgba(255,255,255,0.14)', color: '#9CA3AF' }}
                >
                  Live Demo
                </a>
              </div>
            </div>

            <div
              className="h-64 lg:h-auto flex items-center justify-center min-h-64"
              style={{ background: 'linear-gradient(135deg, rgba(20,184,166,0.04), rgba(59,130,246,0.08))' }}
            >
              <div className="text-center p-8">
                <div className="text-8xl mb-4">📊</div>
                <div className="text-xs text-gray-600 font-medium">Financial Analyzer · Dashboard View</div>
              </div>
            </div>
          </div>
        </div>

        {/* Project grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {projects.slice(1).map((project, i) => (
            <ProjectCard key={project.title} project={project} index={i + 1} />
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Experience ───────────────────────────────────────────────────────────

function Experience() {
  return (
    <section id="experience" className="py-24 border-b" style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <SectionLabel>Journey</SectionLabel>
          <SectionTitle>
            Experience &{' '}
            <span className="gradient-text">Education</span>
          </SectionTitle>
        </div>

        {/* Timeline */}
        <div className="relative max-w-4xl mx-auto">
          <div
            className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px"
            style={{
              background: 'linear-gradient(to bottom, #14B8A6, #3B82F6, #8B5CF6, rgba(139,92,246,0))',
            }}
          />

          {timelineItems.map((item, i) => {
            const isLeft = i % 2 === 0
            return (
              <div
                key={i}
                className={`relative flex mb-12 ${isLeft ? 'md:flex-row' : 'md:flex-row-reverse'}`}
              >
                <div className={`pl-20 md:pl-0 md:w-1/2 ${isLeft ? 'md:pr-12' : 'md:pl-12'}`}>
                  <div className="glass-card rounded-2xl p-6 gradient-border">
                    <div className="flex items-center gap-2 mb-3">
                      <span
                        className="text-xs font-semibold px-2 py-0.5 rounded"
                        style={{
                          background: 'rgba(20,184,166,0.1)',
                          color: '#14B8A6',
                          fontFamily: "'JetBrains Mono', monospace",
                        }}
                      >
                        {item.year}
                      </span>
                      <span className="text-xs text-gray-600 capitalize">{item.type}</span>
                    </div>
                    <h3 className="font-bold text-white mb-0.5">{item.title}</h3>
                    <div className="text-sm font-medium mb-3" style={{ color: '#14B8A6' }}>
                      {item.org}
                    </div>
                    <p className="text-xs text-gray-400 leading-relaxed mb-4">{item.desc}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {item.tags.map((tag) => (
                        <span
                          key={tag}
                          className="text-xs px-2 py-0.5 rounded"
                          style={{
                            background: 'rgba(255,255,255,0.04)',
                            color: '#6B7280',
                            fontFamily: "'JetBrains Mono', monospace",
                          }}
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Dot */}
                <div
                  className="absolute left-8 md:left-1/2 top-6 -translate-x-1/2 w-3.5 h-3.5 rounded-full border-2 z-10"
                  style={{ background: '#0B1120', borderColor: '#14B8A6' }}
                />

                <div className="hidden md:block md:w-1/2" />
              </div>
            )
          })}
        </div>

        {/* Education card */}
        <div className="glass-card rounded-2xl p-8 max-w-4xl mx-auto gradient-border">
          <div className="flex flex-col md:flex-row gap-6 items-start">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
              style={{ background: 'linear-gradient(135deg, #14B8A6, #3B82F6)' }}
            >
              🎓
            </div>
            <div className="flex-1">
              <div className="text-xs font-semibold tracking-widest uppercase mb-1.5" style={{ color: '#14B8A6' }}>
                Education
              </div>
              <h3 className="text-lg font-bold text-white mb-1">
                Bachelor of Technology — Computer Science & Engineering
              </h3>
              <div className="text-sm text-gray-400 mb-3">
                XYZ University &nbsp;·&nbsp; Expected Graduation: May 2026
              </div>
              <p className="text-xs text-gray-500 mb-4 leading-relaxed">
                Relevant coursework: Machine Learning, Deep Learning, Computer Vision, Data Structures & Algorithms, Probability & Statistics, Linear Algebra, Database Management Systems
              </p>
              <div className="flex flex-wrap gap-2">
                {['CGPA: 8.5 / 10', 'ML Research Club', 'Hackathon Winner ×2', 'Kaggle Competitions'].map((item) => (
                  <span
                    key={item}
                    className="text-xs px-3 py-1 rounded-full"
                    style={{
                      background: 'rgba(20,184,166,0.09)',
                      color: '#14B8A6',
                      border: '1px solid rgba(20,184,166,0.18)',
                    }}
                  >
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Currently Learning ───────────────────────────────────────────────────

function CurrentlyLearning() {
  const { ref, inView } = useInView(0.2)

  return (
    <section className="py-24 border-b" style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <SectionLabel>In Progress</SectionLabel>
          <SectionTitle>
            Currently <span className="gradient-text">Learning</span>
          </SectionTitle>
          <p className="text-gray-500 mt-4 max-w-lg mx-auto text-sm">
            The frontier moves fast. Active exploration areas — tracked by weekly study hours.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-3xl mx-auto" ref={ref}>
          {currentlyLearning.map((item, i) => (
            <div key={item.topic} className="glass-card rounded-2xl p-6 gradient-border">
              <div className="flex items-center gap-3 mb-4">
                <div className="text-2xl">{item.icon}</div>
                <div className="font-semibold text-white text-sm">{item.topic}</div>
                <div
                  className="ml-auto text-sm font-semibold"
                  style={{ fontFamily: "'JetBrains Mono', monospace", color: item.color }}
                >
                  {item.progress}%
                </div>
              </div>
              <div className="h-2 rounded-full overflow-hidden mb-2" style={{ background: 'rgba(255,255,255,0.06)' }}>
                <div
                  className="h-full rounded-full"
                  style={{
                    width: inView ? `${item.progress}%` : '0%',
                    background: item.color,
                    transition: `width 1400ms cubic-bezier(0.25,0.46,0.45,0.94) ${i * 200}ms`,
                    boxShadow: `0 0 8px ${item.color}55`,
                  }}
                />
              </div>
              <div className="text-xs text-gray-600">Active study · {item.progress < 50 ? 'Early exploration' : item.progress < 70 ? 'Building foundations' : 'Deep dive'}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Certifications ───────────────────────────────────────────────────────

function Certifications() {
  return (
    <section className="py-24 border-b" style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <SectionLabel>Credentials</SectionLabel>
          <SectionTitle>
            <span className="gradient-text">Certifications</span>
          </SectionTitle>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {certifications.map((cert) => (
            <div
              key={cert.title}
              className="glass-card rounded-2xl p-5 gradient-border flex items-start gap-4"
            >
              <div
                className="w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center text-lg"
                style={{ background: `${cert.color}18`, border: `1px solid ${cert.color}28` }}
              >
                🏅
              </div>
              <div>
                <div className="font-semibold text-white text-sm leading-tight">{cert.title}</div>
                <div className="text-xs text-gray-500 mt-0.5">{cert.issuer}</div>
                <div
                  className="text-xs mt-1.5 font-semibold"
                  style={{ fontFamily: "'JetBrains Mono', monospace", color: cert.color }}
                >
                  {cert.date}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── GitHub ───────────────────────────────────────────────────────────────

function GitHub() {
  const contribColors = ['#1F2937', '#134E4A', '#0F766E', '#0D9488', '#14B8A6']

  return (
    <section className="py-24 border-b" style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <SectionLabel>Open Source</SectionLabel>
          <SectionTitle>
            GitHub <span className="gradient-text">Activity</span>
          </SectionTitle>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Contribution graph */}
          <div className="lg:col-span-2 glass-card rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-semibold text-white">Contribution Activity — 2024</h3>
              <span className="text-xs text-gray-500">847 contributions</span>
            </div>
            <div
              className="overflow-x-auto"
              style={{ display: 'grid', gridTemplateColumns: 'repeat(52, 1fr)', gap: '2px' }}
            >
              {contribGrid.map((level, i) => (
                <div
                  key={i}
                  className="rounded-sm"
                  style={{
                    background: contribColors[level],
                    aspectRatio: '1',
                    minWidth: '8px',
                    minHeight: '8px',
                  }}
                  title={`Level ${level}`}
                />
              ))}
            </div>
            <div className="flex items-center gap-2 mt-3 text-xs text-gray-600">
              <span>Less</span>
              {contribColors.map((c) => (
                <div key={c} className="w-2.5 h-2.5 rounded-sm" style={{ background: c }} />
              ))}
              <span>More</span>
            </div>
          </div>

          {/* Language & stats */}
          <div className="glass-card rounded-2xl p-6">
            <h3 className="text-sm font-semibold text-white mb-4">Languages Used</h3>
            <div className="space-y-3 mb-6">
              {[
                { lang: 'Python', pct: 68, color: '#3B82F6' },
                { lang: 'Jupyter Notebook', pct: 15, color: '#14B8A6' },
                { lang: 'C++', pct: 9, color: '#8B5CF6' },
                { lang: 'JavaScript', pct: 5, color: '#F59E0B' },
                { lang: 'Other', pct: 3, color: '#374151' },
              ].map((l) => (
                <div key={l.lang}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-gray-400">{l.lang}</span>
                    <span className="text-gray-600">{l.pct}%</span>
                  </div>
                  <div className="h-1.5 rounded-full" style={{ background: 'rgba(255,255,255,0.06)' }}>
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${l.pct}%`, background: l.color }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t" style={{ borderColor: 'rgba(255,255,255,0.06)' }}>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { label: 'Repos', value: '42' },
                  { label: 'Stars', value: '128' },
                  { label: 'Forks', value: '34' },
                  { label: 'Followers', value: '87' },
                ].map((s) => (
                  <div key={s.label} className="text-center p-2 rounded-lg" style={{ background: 'rgba(255,255,255,0.03)' }}>
                    <div className="text-base font-bold" style={{ color: '#14B8A6' }}>{s.value}</div>
                    <div className="text-xs text-gray-600">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Recent repos */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-5">
          {projects.slice(0, 3).map((p) => (
            <div key={p.title} className="glass-card rounded-xl p-4 gradient-border">
              <div className="flex items-start justify-between mb-2">
                <div className="font-medium text-white text-sm leading-tight">{p.title}</div>
                <svg className="w-4 h-4 text-gray-600 flex-shrink-0 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                </svg>
              </div>
              <p className="text-xs text-gray-600 mb-3 line-clamp-2">{p.desc}</p>
              <div className="flex items-center gap-3 text-xs text-gray-600">
                <span>⭐ {[22, 41, 18][projects.indexOf(p)] ?? 12}</span>
                <span>🍴 {[8, 14, 6][projects.indexOf(p)] ?? 4}</span>
                <span className="ml-auto font-medium" style={{ color: p.accent }}>
                  ● {p.tech[0]}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Contact ──────────────────────────────────────────────────────────────

function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [sent, setSent] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSent(true)
    setForm({ name: '', email: '', message: '' })
    setTimeout(() => setSent(false), 4000)
  }

  const inputStyle: React.CSSProperties = {
    background: 'rgba(255,255,255,0.04)',
    border: '1px solid rgba(255,255,255,0.08)',
    borderRadius: '12px',
    padding: '12px 16px',
    fontSize: '14px',
    color: '#F9FAFB',
    width: '100%',
    outline: 'none',
    transition: 'border-color 0.2s',
  }

  return (
    <section id="contact" className="py-24 border-b" style={{ borderColor: 'rgba(255,255,255,0.04)' }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <SectionLabel>Get In Touch</SectionLabel>
          <SectionTitle>
            {"Let's"} <span className="gradient-text">Connect</span>
          </SectionTitle>
          <p className="text-gray-500 mt-4 max-w-lg mx-auto text-sm">
            Open to full-time roles, internships, research collaborations, and freelance AI projects.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
          <div>
            <p className="text-gray-400 leading-relaxed mb-8 text-sm">
              Whether you have an opportunity at a top AI lab, want to collaborate on something
              interesting, or just want to talk about AI — drop me a message.
            </p>

            <div className="space-y-3">
              {[
                { icon: '✉️', label: 'Email', value: 'manav.arora@email.com', href: 'mailto:manav.arora@email.com' },
                { icon: '💼', label: 'LinkedIn', value: 'linkedin.com/in/manavarora', href: '#' },
                { icon: '💻', label: 'GitHub', value: 'github.com/manavarora', href: '#' },
                { icon: '📍', label: 'Location', value: 'India — Remote Ready', href: null },
              ].map((c) => (
                <div
                  key={c.label}
                  className="glass-card rounded-xl p-4 flex items-center gap-4 gradient-border"
                >
                  <div className="text-xl w-8 text-center">{c.icon}</div>
                  <div>
                    <div className="text-xs text-gray-600 uppercase tracking-wider mb-0.5">{c.label}</div>
                    {c.href ? (
                      <a
                        href={c.href}
                        className="text-sm font-medium text-gray-200 hover:text-teal-400 transition-colors"
                      >
                        {c.value}
                      </a>
                    ) : (
                      <div className="text-sm font-medium text-gray-200">{c.value}</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card rounded-2xl p-8">
            <form onSubmit={handleSubmit}>
              <div className="mb-5">
                <label className="block text-xs font-medium text-gray-400 mb-2">Name</label>
                <input
                  type="text"
                  value={form.name}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                  style={inputStyle}
                  placeholder="Your full name"
                  required
                />
              </div>
              <div className="mb-5">
                <label className="block text-xs font-medium text-gray-400 mb-2">Email</label>
                <input
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                  style={inputStyle}
                  placeholder="your@email.com"
                  required
                />
              </div>
              <div className="mb-6">
                <label className="block text-xs font-medium text-gray-400 mb-2">Message</label>
                <textarea
                  value={form.message}
                  onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                  rows={5}
                  style={{ ...inputStyle, resize: 'none' }}
                  placeholder="Tell me about the opportunity or project..."
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 rounded-xl text-sm font-semibold text-white transition-all hover:scale-105 hover:brightness-110"
                style={{
                  background: sent
                    ? 'linear-gradient(135deg, #10B981, #14B8A6)'
                    : 'linear-gradient(135deg, #14B8A6, #3B82F6)',
                  boxShadow: '0 0 20px rgba(20,184,166,0.2)',
                }}
              >
                {sent ? '✓ Message Sent!' : 'Send Message →'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}

// ─── Footer ───────────────────────────────────────────────────────────────

function Footer() {
  return (
    <footer className="py-10">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div
            className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold text-white"
            style={{ background: 'linear-gradient(135deg, #14B8A6, #3B82F6)' }}
          >
            MA
          </div>
          <span className="text-sm text-gray-600">© 2024 Manav Arora. All rights reserved.</span>
        </div>

        <div className="flex items-center gap-2">
          {[
            {
              label: 'GitHub',
              href: '#',
              d: 'M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0 0 24 12c0-6.63-5.37-12-12-12z',
            },
            {
              label: 'LinkedIn',
              href: '#',
              d: 'M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z',
            },
          ].map((s) => (
            <a
              key={s.label}
              href={s.href}
              aria-label={s.label}
              className="p-2 rounded-lg text-gray-600 hover:text-white hover:bg-white/5 transition-all"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d={s.d} />
              </svg>
            </a>
          ))}
        </div>

        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="text-xs text-gray-600 hover:text-white transition-colors flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-white/5"
        >
          Back to top ↑
        </button>
      </div>
    </footer>
  )
}

// ─── App ──────────────────────────────────────────────────────────────────

export default function App() {
  return (
    <div style={{ background: '#0B1120', minHeight: '100vh' }}>
      <Navbar />
      <Hero />
      <Stats />
      <About />
      <Skills />
      <Projects />
      <Experience />
      <CurrentlyLearning />
      <Certifications />
      <GitHub />
      <Contact />
      <Footer />
    </div>
  )
}
